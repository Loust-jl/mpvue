<?php
    header("Content-Type:text/html; charset=utf-8");//解决中文乱码
    header("Access-Control-Allow-Origin: *"); //解决跨域
    header('Access-Control-Allow-Methods:post');// 响应类型
    // mysql_set_charset('utf-8');//解决中文乱码问题
    // $con =mysql_connect("localhost", "root", "root");
    // mysql_select_db("my_lunbo", $con); //选择数据库
    
    // 接收前端传过来的参数
    $code =$_POST["code"];
    $url='https://api.weixin.qq.com/sns/jscode2session?appid=wxc872fc2f50579719&secret=db859ec287d1e4135efaf91b9b54abcf&js_code='.$code.'&grant_type=authorization_code';
    $json = file_get_contents($url);
    //只返回openid，json是一个json对象
    $array = json_decode($json, true);
    $obj = json_decode($json);
    $openid = $obj->openid;
    //初始化返回数组
    $arr = array(
    'code' => 0,
    'msg'=> '',
    'data' =>array(
         'openid' =>''
         ),
    );
    if ($openid!='') {
        $arr['msg'] ="登录成功";
      
      
       $con = mysql_connect("localhost","root","root");
       if (!$con)
         {
         die('Could not connect: ' . mysql_error());
         }
       
       if (mysql_query("CREATE DATABASE my_lunbo",$con))
         {
         // echo "Database created";
         }
       else
         {
         // echo "Error creating database: " . mysql_error();
         }
       
	 mysql_select_db("my_lunbo", $con);
	 $sql = "CREATE TABLE user 
	 (
	 openid text,
	 id int
	 )";
	 mysql_query($sql,$con);

	   mysql_select_db("my_lunbo", $con);
	   
	   mysql_query("INSERT INTO user (openid, id) 
	   VALUES ('$openid', '')");
       mysql_close($con);
	   
        $arr['data']['openid'] =$openid;
    }
        
     echo json_encode($arr);
