<?php
    header("Content-Type:text/html; charset=utf-8");
    header("Access-Control-Allow-Origin: *"); //解决跨域
    header('Access-Control-Allow-Methods:post');// 响应类型
    // mysql_set_charset('utf-8');//解决中文乱码问题
    date_default_timezone_set('PRC');//获取当前时间
//上传文件目录获取
$month = date('Ym', time());
define('BASE_PATH', str_replace('\\', '/', realpath(dirname(__FILE__).'/'))."/");
$dir = BASE_PATH."upload/".$month."/";
 
//初始化返回数组
$arr = array(
'code' => 0,
'msg'=> '',
'data' =>array(
     'src' => $dir . $_FILES["file"]["name"]
     ),
);
 
$file_info = $_FILES['file'];
 $file_error = $file_info['error'];
if (!is_dir($dir)) {//判断目录是否存在
    mkdir($dir, 0777, true);//如果目录不存在则创建目录
};
$file = $dir.$_FILES["file"]["name"];
if (!file_exists($file)) {
    if ($file_error == 0) {
        if (move_uploaded_file($_FILES["file"]["tmp_name"], $dir. $_FILES["file"]["name"])) {
            $arr['msg'] ="上传成功";
            // ---a
            $con = mysql_connect("localhost", "root", "root");//链接数据库
            if (!$con) {
                die('Could not connect: ' . mysql_error());
            }

            if (mysql_query("CREATE DATABASE my_lunbo", $con)) {//新建数据库
                // echo "Database created";
            } else {
                // echo "Error creating database: " . mysql_error();
            }
            //在my_lunbo数据库中新建my_lunboImg数据表
            mysql_select_db("my_lunbo", $con);
            //新建数据表 my_lunboImg 表名 my_lunboImg 字段名
            $sql = "CREATE TABLE my_lunboimg  
			(
			lb_imgUrl text,
			typeid text,
			id int
			)";
            mysql_query($sql, $con);
            //将$file字符串中的'D:/php/PHPTutorial/WWW'字符串改为域名
			$imgurl=str_replace('D:/php/PHPTutorial/WWW', 'https://www.jayjing.wang', $file);
			 $arr['data']['src'] =$imgurl;//将链接赋值给返回数组中的data里的src
            mysql_select_db("my_lunbo", $con);//链接数据库
            // 向数据库添加数据
            mysql_query("INSERT INTO my_lunboimg (lb_imgUrl, typeid, id) 
		VALUES ('$imgurl' , '1', '')");

            mysql_close($con);
        // ---a
        } else {
            $arr['msg'] = "上传失败";
        }
    } else {
        switch ($file_error) {
            case 1:
           $arr['msg'] ='上传文件超过了PHP配置文件中upload_max_filesize选项的值';
                break;
            case 2:
              $arr['msg'] ='超过了表单max_file_size限制的大小';
                break;
            case 3:
               $arr['msg'] ='文件部分被上传';
                break;
            case 4:
              $arr['msg'] ='没有选择上传文件';
                break;
            case 6:
                $arr['msg'] ='没有找到临时文件';
                break;
            case 7:
            case 8:
               $arr['msg'] = '系统错误';
                break;
        }
    }
} else {
    $arr['code'] ="1";
    $arr['msg'] = "当前目录中，文件".$file."已存在";
}
 
  echo json_encode($arr);
