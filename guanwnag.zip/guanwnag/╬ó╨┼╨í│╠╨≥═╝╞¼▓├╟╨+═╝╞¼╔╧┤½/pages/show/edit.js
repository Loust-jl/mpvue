var app = getApp();
Page({
  data: {
    // 图片列表
    pics: [],
    listData: [],
    value: '',
    // 昵称
    nickname: '',
    // 生日
    birthday: '',
    // 保留
    retain: '',
    // 所在地
    location: '',
    // qq
    qq: '',
    // 微信
    wx: '',
    // 手机号
    phone: '',
    // 初中
    junior: '',
    // 高中
    high: '',
    // 中专
    secondary: '',
    // 大学
    university: '',
    // 个签
    signatureText: '',
    // 裁切
    cuttype: null,
  },
  // 页面加载
  onLoad: function(options) {

  },
  onShow(e) {
    if (this.data.cuttype) {
    
      this.setData({
        pics: this.data.pics.concat(this.data.src)
      })
      // 
      this.aa()
    }
  },
  // 打印裁切过后图片的数组
  aa() { console.log(this.data.pics)},
  chooseIMG() {
    wx.navigateTo({
      url: '/pages/cutFace/index?cuttype=1',
    })
  },
  // 上传图片
  uploadimg: function() { //这里触发图片上传的方法
    var pics = this.data.pics;
    console.log(11111111111111, pics)
    let i;
    for (i = 0; i < pics.length;i++){
      console.log(2222, pics[i])
      wx.uploadFile({
        url: 'http://localhost/guanwnag/php/up.php', //本地测试
        filePath: pics[i],
        name: 'file',
        formData: {
        },
        success(res) {
          console.log(res)
          const data = JSON.parse(res.data)
          console.log(data)
          //do something
        }
      })
    }

  },
  // 删除图片
  imgDelete1(e) {
    // console.log(e)
    let index = e.currentTarget.dataset.deindex
    var list = this.data.pics
    list.splice(index, 1)
    this.data.listData.pics = list
    this.setData({
      pics: list
    })
  },

})