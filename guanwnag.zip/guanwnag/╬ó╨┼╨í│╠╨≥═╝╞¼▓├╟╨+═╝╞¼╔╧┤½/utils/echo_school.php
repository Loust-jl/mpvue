<?php
header("content-type:text/html;charset=utf-8");
header('Content-type: application/json');

$province_name = $_POST["province"];  // 省名
$city_name = $_POST["city"];		  // 市名
$school_type = $_POST["school_type"]; // 学校类型: 初中、中专、高中、大学

$tmp_pwd = $school_type.'/'.$province_name.'/'.$city_name.'.txt';
// 从文件中读取数据到PHP变量
$my_school = file_get_contents($tmp_pwd);

if($my_school != false)
{
	echo $my_school;// 返回一个市的数据
}
// 关闭文件
fclose($my_school);
?>